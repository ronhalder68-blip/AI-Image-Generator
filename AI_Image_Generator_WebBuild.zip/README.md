# AI Image Generator — Android + Secure Backend

This project is designed so the large AI model stays online/server-side.
The Android app does NOT contain a provider API key.

## Android
1. Open this folder in Android Studio.
2. In `MainActivity.kt`, replace `YOUR-BACKEND-DOMAIN.example` with your HTTPS backend.
3. Build APK: Build > Generate App Bundles or APKs > Generate APKs.

## Backend
Run:
npm install express
node server.js

Then connect `/generate` to your chosen FLUX/SDXL-compatible provider.
Store the provider secret as an environment variable, never in the APK.

The word "unlimited" means no artificial per-image limit in this app; actual usage depends on the provider/GPU/server capacity and its terms.
