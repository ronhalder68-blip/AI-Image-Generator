// Secure backend example.
// Keep the real provider API key ONLY on the server.
// Set PROVIDER_API_KEY in your server environment.
//
// npm install express
// node server.js
const express = require("express");
const app = express();
app.use(express.json({limit:"1mb"}));

app.post("/generate", async (req,res) => {
  const {prompt, negative_prompt, model} = req.body || {};
  if (!prompt) return res.status(400).json({error:"prompt required"});

  // TODO: call your chosen online image provider here using PROVIDER_API_KEY.
  // Return a generated image URL or base64 data:
  // res.json({image_url:"https://..."});
  res.status(501).json({
    error:"Connect your selected FLUX/SDXL provider in server.js",
    received:{prompt, negative_prompt, model}
  });
});

app.listen(process.env.PORT || 8080, () => console.log("AI backend running"));
