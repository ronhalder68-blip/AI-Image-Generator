package com.ronhalder.aiimagegenerator

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val backendUrl = "https://YOUR-BACKEND-DOMAIN.example/generate"
    private lateinit var prompt: EditText
    private lateinit var negative: EditText
    private lateinit var model: Spinner
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(16,16,20))
        }

        fun label(text: String) = TextView(this).apply {
            this.text = text; setTextColor(Color.WHITE); textSize = 15f
            setPadding(0, 12, 0, 6)
        }

        val title = TextView(this).apply {
            text = "✨ AI Image Generator"; textSize = 25f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        root.addView(label("Prompt"))
        prompt = EditText(this).apply {
            hint = "Describe the image..."
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setBackgroundColor(Color.rgb(35,35,42))
            minLines = 3; gravity = Gravity.TOP
        }
        root.addView(prompt, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(label("Negative prompt"))
        negative = EditText(this).apply {
            hint = "Optional"
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setBackgroundColor(Color.rgb(35,35,42))
        }
        root.addView(negative, LinearLayout.LayoutParams(-1, -2))

        root.addView(label("Model"))
        model = Spinner(this)
        model.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("FLUX", "SDXL"))
        root.addView(model, LinearLayout.LayoutParams(-1, -2))

        val generate = Button(this).apply {
            text = "GENERATE IMAGE"
            setOnClickListener { generateImage() }
        }
        root.addView(generate, LinearLayout.LayoutParams(-1, -2))

        status = TextView(this).apply {
            text = "Ready — connect your secure backend to generate."
            setTextColor(Color.LTGRAY); textSize = 14f
            setPadding(0, 14, 0, 0)
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
    }

    private fun generateImage() {
        val p = prompt.text.toString().trim()
        if (p.isEmpty()) { prompt.error = "Enter a prompt"; return }
        status.text = "Generating online…"
        thread {
            try {
                val conn = URL(backendUrl).openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                val body = JSONObject().apply {
                    put("prompt", p)
                    put("negative_prompt", negative.text.toString())
                    put("model", model.selectedItem.toString())
                }.toString()
                conn.outputStream.use { it.write(body.toByteArray()) }
                val response = conn.inputStream.bufferedReader().readText()
                runOnUiThread { status.text = "Done. Backend response received." }
                conn.disconnect()
            } catch (e: Exception) {
                runOnUiThread { status.text = "Backend not connected yet: ${e.message}" }
            }
        }
    }
}
