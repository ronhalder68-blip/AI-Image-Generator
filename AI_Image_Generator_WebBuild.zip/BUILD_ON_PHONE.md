# Build the APK using only your phone

You do NOT need AIDE or a 600 MB Android IDE.

## GitHub Actions method

1. Create/sign in to a GitHub account in your phone browser.
2. Create a new repository, e.g. `AI-Image-Generator`.
3. Upload all files/folders from this ZIP to the repository. Make sure `.github/workflows/build-apk.yml` is uploaded too.
4. Open the repository → **Actions**.
5. Select **Build APK** → **Run workflow**.
6. Wait for the build to finish.
7. Open the completed workflow run and download the artifact named:
   `AI-Image-Generator-debug`
8. Extract the artifact ZIP and install `app-debug.apk`.

This uses GitHub's cloud build machine, so your phone does not need Android Studio/AIDE.

IMPORTANT:
The APK currently contains a placeholder backend URL. The UI can be built now, but actual FLUX/SDXL generation will only work after a real secure backend URL is configured in `MainActivity.kt`.
